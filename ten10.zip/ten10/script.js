/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   MUSIC TOGGLE
   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
const music     = document.getElementById('bg-music');
const musicBtn  = document.getElementById('music-toggle');
const musicLbl  = musicBtn.querySelector('.music-label');

let playing = false;

musicBtn.addEventListener('click', async () => {
  if (playing) {
    music.pause();
    musicBtn.classList.remove('playing');
    musicLbl.textContent = 'tap to play music';
    playing = false;
  } else {
    try {
      await music.play();
      musicBtn.classList.add('playing');
      musicLbl.textContent = 'now playing';
      playing = true;
    } catch (err) {
      musicLbl.textContent = 'no music file found';
      console.warn('Music could not play. Make sure music.mp3 is in the same folder.', err);
    }
  }
});

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   FLIP CARDS  +  CONFETTI ON ALL-FLIPPED
   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
const cards = document.querySelectorAll('.card');
const flipped = new Set();
let confettiFired = false;

cards.forEach(card => {
  const flip = () => {
    card.classList.toggle('flipped');
    if (card.classList.contains('flipped')) flipped.add(card);
    else flipped.delete(card);

    if (flipped.size === cards.length && !confettiFired) {
      confettiFired = true;
      burstConfetti();
    }
  };

  card.addEventListener('click', flip);
  card.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      flip();
    }
  });
});

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   BOX OF CHOCOLATES
   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
const chocolateBox = document.getElementById('chocolate-box');
const chocolateMsg = document.querySelector('.chocolate-message');

const messages = [
  "You're sharper than a Highland breeze.",
  "Quesadillas really are a love language.",
  "Run, Forrest, run!",
  "Stupid is as stupid does.",
  "Two homelands, one heart.",
  "Cross country builds character — and you've got plenty.",
  "Some people just make the world more colorful.",
  "Life's better with cheese involved."
];

// build 8 chocolates
for (let i = 0; i < 8; i++) {
  const c = document.createElement('button');
  c.className = 'chocolate';
  c.setAttribute('aria-label', `Chocolate ${i + 1}`);
  chocolateBox.appendChild(c);
}

// shuffled queue so each pick is different
let queue = [...messages].sort(() => Math.random() - 0.5);

chocolateBox.addEventListener('click', (e) => {
  const choc = e.target.closest('.chocolate');
  if (!choc || choc.classList.contains('eaten')) return;

  choc.classList.add('eaten');

  const msg = queue.shift() || "You found a special one — keep being you.";

  chocolateMsg.style.opacity = '0';
  setTimeout(() => {
    chocolateMsg.textContent = `"${msg}"`;
    chocolateMsg.style.opacity = '1';
  }, 200);
});

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   CONFETTI BURST
   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
function burstConfetti() {
  const colors = ['#a23b2d', '#e9a13e', '#3a6b35', '#f4a4a4', '#1f1f1d', '#ecdfb8'];
  for (let i = 0; i < 90; i++) {
    const piece = document.createElement('div');
    piece.className = 'confetti';
    piece.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
    piece.style.left = Math.random() * 100 + 'vw';
    piece.style.animationDuration = (2 + Math.random() * 2.2) + 's';
    piece.style.animationDelay = (Math.random() * 0.4) + 's';
    piece.style.transform = `rotate(${Math.random() * 360}deg)`;
    document.body.appendChild(piece);
    setTimeout(() => piece.remove(), 5500);
  }
}

/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   EASTER EGG: tap the name a bunch of times
   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
const heroName = document.querySelector('.hero-name');
let nameClicks = 0;

heroName.addEventListener('click', () => {
  nameClicks++;
  const wobble = (Math.random() - 0.5) * 8;
  heroName.style.transform = `rotate(${wobble}deg) scale(${1 + Math.random() * 0.06})`;
  setTimeout(() => { heroName.style.transform = ''; }, 280);

  if (nameClicks === 5) burstConfetti();
});
